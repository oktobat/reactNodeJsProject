import React from 'react';
import MemberTemp from '../components/MemberTemp'

const Join = () => {
    return (
        <MemberTemp type="join" />
    );
};

export default Join;