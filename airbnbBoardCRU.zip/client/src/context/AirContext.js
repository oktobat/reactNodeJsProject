import { createContext } from 'react'
export const AirContext = createContext(null)